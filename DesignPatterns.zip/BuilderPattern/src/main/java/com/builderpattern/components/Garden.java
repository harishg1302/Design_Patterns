package com.builderpattern.components;

public class Garden {
	private int trees;

	public int getTrees() {
		return trees;
	}

	public Garden(int trees) {
		this.trees = trees;
	}

}
