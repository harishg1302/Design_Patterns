package com.factorymethod.products;

public class BrandedProduct implements Product{

	public void produce() {
		System.out.print("Branded_Product");
	}

}
