package com.factorymethod.products;

public class SecondHandProduct implements Product {

	public void produce() {
		System.out.print("Second_Hand_product");
		
	}

}
