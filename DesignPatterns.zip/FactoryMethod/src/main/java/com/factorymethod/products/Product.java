package com.factorymethod.products;

public interface Product {
	
	public void produce();

}
