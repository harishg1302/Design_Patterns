package com.factorymethod.products;

public class HomeMadeProduct implements Product{

	public void produce() {
		System.out.print("Home_Made_Suit");
	}

}
