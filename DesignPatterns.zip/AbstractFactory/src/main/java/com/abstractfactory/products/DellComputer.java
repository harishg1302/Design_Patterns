package com.abstractfactory.products;

public class DellComputer implements Computer {

	@Override
	public void getProduct() {
		System.out.println("My Dell_Computer");
	}

}
