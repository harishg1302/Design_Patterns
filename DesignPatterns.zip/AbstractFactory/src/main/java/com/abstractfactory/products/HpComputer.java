package com.abstractfactory.products;

public class HpComputer implements Computer {

	@Override
	public void getProduct() {
		System.out.println("My HP_Computer");
	}

}
