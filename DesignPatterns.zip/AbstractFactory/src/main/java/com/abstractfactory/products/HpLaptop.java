package com.abstractfactory.products;

public class HpLaptop implements Laptop {

	@Override
	public void getProduct() {
		System.out.println("My HP_Laptop");
	}


}
