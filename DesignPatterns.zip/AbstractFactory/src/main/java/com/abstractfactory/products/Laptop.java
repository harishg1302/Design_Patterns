package com.abstractfactory.products;

public interface Laptop {
	
	public void getProduct();
	
	

}
