package com.abstractfactory.products;

public interface Computer {

	public void getProduct();
}
