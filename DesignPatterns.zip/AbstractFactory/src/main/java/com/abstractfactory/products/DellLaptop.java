package com.abstractfactory.products;

public class DellLaptop implements Laptop {

	@Override
	public void getProduct() {
		System.out.print("My Dell_Laptop");
	}

}
